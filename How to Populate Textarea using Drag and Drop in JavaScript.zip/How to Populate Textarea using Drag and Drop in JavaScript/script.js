var movie_list=[];

function dragOver(e){
		e.preventDefault();
}
	
function drop(e){
	e.preventDefault();
	var data = e.dataTransfer.getData("data");
	
	document.getElementById('input').value = data;
}

function drag(e){
	e.dataTransfer.setData("data", e.target.id);
}

function submit(){
	var input = document.getElementById('input').value;
	movie_list.push(input);
	var data=movie_list.join(" ,");
	if(input !=""){
		document.getElementById('result').innerHTML = data;
		document.getElementById('input').value="";
		document.getElementById('btn_reset').style.display="inline";
	}else{
		alert("Please drag something first!");
	}
}

function reset(){
	document.getElementById('result').innerHTML = "";
	movie_list=[];
	document.getElementById('btn_reset').style.display="none";
}